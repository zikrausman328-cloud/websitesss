BUSGO - BUS SERVICE + HYBRID ARCHITECTURE DEMO

Requirements:
- Visual Studio 2022
- ASP.NET and web development workload
- .NET 8 SDK (or retarget the project to an installed SDK)

Open:
1. Extract the ZIP.
2. Open BusServiceHybridArchitecture.sln in Visual Studio.
3. Wait for restore to finish.
4. Press F5.

Business functionality:
- Search bus routes by departure and destination city
- View bus company, departure time and fare
- Book 1 to 6 seats
- Validate passenger name and email
- Calculate total fare
- Check remaining seat capacity before confirming
- View all bookings
- Cancel a confirmed booking and release its seats

Hybrid architecture:
- Controllers handle web requests
- Models represent routes, bookings and events
- RouteService provides route data
- BookingService contains reservation business rules
- EventBusService publishes booking events
- ActivityLogService subscribes to events and records them
- Activity page displays the event history

Important:
This is a classroom demo. Sample routes and bookings are stored in memory and reset when the app restarts. It does not process real payments or provide live bus-company schedules.
