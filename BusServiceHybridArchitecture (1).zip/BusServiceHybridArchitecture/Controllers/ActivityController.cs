using BusServiceHybridArchitecture.Services;
using Microsoft.AspNetCore.Mvc;

namespace BusServiceHybridArchitecture.Controllers;

public class ActivityController : Controller
{
    private readonly ActivityLogService activityLog;

    public ActivityController(ActivityLogService activityLog)
    {
        this.activityLog = activityLog;
    }

    public IActionResult Index() => View(activityLog.GetLatest());
}
