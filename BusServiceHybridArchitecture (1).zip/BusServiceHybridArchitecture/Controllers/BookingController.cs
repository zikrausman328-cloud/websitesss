using BusServiceHybridArchitecture.Models;
using BusServiceHybridArchitecture.Services;
using Microsoft.AspNetCore.Mvc;

namespace BusServiceHybridArchitecture.Controllers;

public class BookingController : Controller
{
    private readonly BookingService bookingService;
    private readonly RouteService routeService;

    public BookingController(BookingService bookingService, RouteService routeService)
    {
        this.bookingService = bookingService;
        this.routeService = routeService;
    }

    [HttpGet]
    public IActionResult Create(int routeId)
    {
        var route = routeService.GetById(routeId);
        if (route is null) return NotFound();

        ViewBag.Route = route;
        return View(new BookingFormModel { RouteId = routeId, Seats = 1 });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Create(BookingFormModel model)
    {
        var route = routeService.GetById(model.RouteId);
        if (route is null) return NotFound();

        ViewBag.Route = route;

        if (!ModelState.IsValid)
            return View(model);

        var result = bookingService.Create(model);
        if (!result.Success)
        {
            ModelState.AddModelError("", result.Message);
            return View(model);
        }

        return RedirectToAction(nameof(Confirmation), new { id = result.Booking!.Id });
    }

    public IActionResult Confirmation(int id)
    {
        var booking = bookingService.GetById(id);
        if (booking is null) return NotFound();

        ViewBag.Route = routeService.GetById(booking.RouteId);
        return View(booking);
    }

    public IActionResult All()
    {
        ViewBag.Routes = routeService.GetAll().ToDictionary(r => r.Id);
        return View(bookingService.GetAll());
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Cancel(int id)
    {
        bookingService.Cancel(id);
        return RedirectToAction(nameof(All));
    }
}
