using Microsoft.AspNetCore.Mvc;
using BusServiceHybridArchitecture.Services;

namespace BusServiceHybridArchitecture.Controllers;

public class HomeController : Controller
{
    private readonly RouteService routeService;

    public HomeController(RouteService routeService)
    {
        this.routeService = routeService;
    }

    public IActionResult Index(string? from, string? to)
    {
        var routes = routeService.GetAll();

        if (!string.IsNullOrWhiteSpace(from))
            routes = routes.Where(r => r.FromCity.Contains(from.Trim(), StringComparison.OrdinalIgnoreCase)).ToList();

        if (!string.IsNullOrWhiteSpace(to))
            routes = routes.Where(r => r.ToCity.Contains(to.Trim(), StringComparison.OrdinalIgnoreCase)).ToList();

        ViewBag.From = from;
        ViewBag.To = to;
        return View(routes);
    }
}
