using BusServiceHybridArchitecture.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();

// Business services
builder.Services.AddSingleton<RouteService>();
builder.Services.AddSingleton<BookingService>();

// Hybrid architecture: event publisher + event consumer/log
builder.Services.AddSingleton<EventBusService>();
builder.Services.AddSingleton<ActivityLogService>();

var app = builder.Build();

// Start the event consumer so it receives events
_ = app.Services.GetRequiredService<ActivityLogService>();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}

app.UseStaticFiles();
app.UseRouting();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
