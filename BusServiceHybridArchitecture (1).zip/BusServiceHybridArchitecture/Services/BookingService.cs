using BusServiceHybridArchitecture.Models;

namespace BusServiceHybridArchitecture.Services;

public class BookingService
{
    private readonly List<BusBooking> bookings = new();
    private readonly object lockObject = new();
    private readonly RouteService routeService;
    private readonly EventBusService eventBus;
    private int nextId = 1;

    public BookingService(RouteService routeService, EventBusService eventBus)
    {
        this.routeService = routeService;
        this.eventBus = eventBus;
    }

    public (bool Success, string Message, BusBooking? Booking) Create(BookingFormModel form)
    {
        var route = routeService.GetById(form.RouteId);
        if (route is null)
            return (false, "Selected bus route was not found.", null);

        if (form.Seats < 1 || form.Seats > 6)
            return (false, "You can book between 1 and 6 seats at a time.", null);

        lock (lockObject)
        {
            var alreadyBooked = bookings
                .Where(b => b.RouteId == route.Id && b.Status == "Confirmed")
                .Sum(b => b.Seats);

            var available = route.TotalSeats - alreadyBooked;
            if (form.Seats > available)
                return (false, $"Only {Math.Max(available, 0)} seat(s) are available.", null);

            var booking = new BusBooking
            {
                Id = nextId++,
                RouteId = route.Id,
                PassengerName = form.PassengerName.Trim(),
                PassengerEmail = form.PassengerEmail.Trim(),
                Seats = form.Seats,
                TotalFare = route.Fare * form.Seats,
                BookedAt = DateTime.Now,
                Status = "Confirmed"
            };

            bookings.Add(booking);
            eventBus.Publish("Booking Created",
                $"{booking.PassengerName} booked {booking.Seats} seat(s) for {route.FromCity} to {route.ToCity} (Booking #{booking.Id}).");

            return (true, "Booking confirmed.", booking);
        }
    }

    public List<BusBooking> GetAll()
    {
        lock (lockObject)
            return bookings.OrderByDescending(b => b.BookedAt).ToList();
    }

    public BusBooking? GetById(int id)
    {
        lock (lockObject)
            return bookings.FirstOrDefault(b => b.Id == id);
    }

    public bool Cancel(int id)
    {
        lock (lockObject)
        {
            var booking = bookings.FirstOrDefault(b => b.Id == id);
            if (booking is null || booking.Status != "Confirmed")
                return false;

            booking.Status = "Cancelled";
            var route = routeService.GetById(booking.RouteId);
            eventBus.Publish("Booking Cancelled",
                $"Booking #{booking.Id} for {booking.PassengerName} was cancelled ({route?.FromCity} to {route?.ToCity}).");
            return true;
        }
    }
}
