using System.Collections.Concurrent;
using BusServiceHybridArchitecture.Models;

namespace BusServiceHybridArchitecture.Services;

// Event consumer: listens for events and records them for the admin activity page.
public class ActivityLogService
{
    private readonly ConcurrentQueue<ActivityEvent> events = new();

    public ActivityLogService(EventBusService eventBus)
    {
        eventBus.EventPublished += Record;
    }

    private void Record(ActivityEvent item) => events.Enqueue(item);

    public IEnumerable<ActivityEvent> GetLatest() => events.ToArray().Reverse();
}
