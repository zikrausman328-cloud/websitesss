using BusServiceHybridArchitecture.Models;

namespace BusServiceHybridArchitecture.Services;

public class RouteService
{
    private readonly List<BusRoute> routes = new()
    {
        new BusRoute { Id = 1, Company = "SkyLine Travels", FromCity = "Lahore", ToCity = "Islamabad", DepartureTime = "08:00 AM", Fare = 2200, TotalSeats = 40 },
        new BusRoute { Id = 2, Company = "Road Master", FromCity = "Lahore", ToCity = "Multan", DepartureTime = "10:30 AM", Fare = 1800, TotalSeats = 36 },
        new BusRoute { Id = 3, Company = "SkyLine Travels", FromCity = "Islamabad", ToCity = "Lahore", DepartureTime = "02:00 PM", Fare = 2200, TotalSeats = 40 },
        new BusRoute { Id = 4, Company = "Punjab Express", FromCity = "Lahore", ToCity = "Faisalabad", DepartureTime = "04:30 PM", Fare = 1000, TotalSeats = 32 },
        new BusRoute { Id = 5, Company = "Road Master", FromCity = "Multan", ToCity = "Lahore", DepartureTime = "06:00 PM", Fare = 1800, TotalSeats = 36 }
    };

    public List<BusRoute> GetAll() => routes.ToList();

    public BusRoute? GetById(int id) => routes.FirstOrDefault(r => r.Id == id);
}
