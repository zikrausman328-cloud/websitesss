using BusServiceHybridArchitecture.Models;

namespace BusServiceHybridArchitecture.Services;

// Event publisher: business services publish events without depending on the log service.
public class EventBusService
{
    public event Action<ActivityEvent>? EventPublished;

    public void Publish(string eventType, string details)
    {
        EventPublished?.Invoke(new ActivityEvent
        {
            EventType = eventType,
            Details = details,
            Time = DateTime.Now
        });
    }
}
