namespace BusServiceHybridArchitecture.Models;

public class ActivityEvent
{
    public string EventType { get; set; } = "";
    public string Details { get; set; } = "";
    public DateTime Time { get; set; } = DateTime.Now;
}
