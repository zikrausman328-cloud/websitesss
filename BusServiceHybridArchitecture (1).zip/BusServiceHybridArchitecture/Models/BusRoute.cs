namespace BusServiceHybridArchitecture.Models;

public class BusRoute
{
    public int Id { get; set; }
    public string Company { get; set; } = "";
    public string FromCity { get; set; } = "";
    public string ToCity { get; set; } = "";
    public string DepartureTime { get; set; } = "";
    public decimal Fare { get; set; }
    public int TotalSeats { get; set; }
}
