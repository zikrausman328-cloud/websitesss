namespace BusServiceHybridArchitecture.Models;

public class BusBooking
{
    public int Id { get; set; }
    public int RouteId { get; set; }
    public string PassengerName { get; set; } = "";
    public string PassengerEmail { get; set; } = "";
    public int Seats { get; set; }
    public decimal TotalFare { get; set; }
    public DateTime BookedAt { get; set; } = DateTime.Now;
    public string Status { get; set; } = "Confirmed";
}
