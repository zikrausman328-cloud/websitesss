using System.ComponentModel.DataAnnotations;

namespace BusServiceHybridArchitecture.Models;

public class BookingFormModel
{
    public int RouteId { get; set; }

    [Required, StringLength(60, MinimumLength = 2)]
    public string PassengerName { get; set; } = "";

    [Required, EmailAddress]
    public string PassengerEmail { get; set; } = "";

    [Range(1, 6)]
    public int Seats { get; set; } = 1;
}
